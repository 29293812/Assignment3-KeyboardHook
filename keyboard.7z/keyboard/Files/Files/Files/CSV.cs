﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace Files
{
    public class CSV
    {
        public static void SaveCSV(TextBox data, string path)
        {
          
            try
            {
              ;
                
                using (StreamWriter writer = new StreamWriter(path))
                {
                    string s = data.Text;
                    // Write a line of text to the file
                    writer.WriteLine(s);

                }
            }
            catch { }
          
        }
    }
}
